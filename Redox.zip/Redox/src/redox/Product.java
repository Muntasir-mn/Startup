/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redox;

/**
 *
 * @author acer
 */
class Product {
    private int productId;
    private String productName;
    private String productCategory;
    private int price;
    private String generation;
    private String processor;
    private double displaySizeBaseInches;
    private String ram;
    private String ramType;
    private String printResoulation;
    private String lens;

    public Product(int productId, String productName, String productCategory, int price, String generation, String processor, double displaySizeBaseInches, String ram, String ramType, String printResoulation, String lens) {
        this.productId = productId;
        this.productName = productName;
        this.productCategory = productCategory;
        this.price = price;
        this.generation = generation;
        this.processor = processor;
        this.displaySizeBaseInches = displaySizeBaseInches;
        this.ram = ram;
        this.ramType = ramType;
        this.printResoulation = printResoulation;
        this.lens = lens;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public int getPrice() {
        return price;
    }

    public String getGeneration() {
        return generation;
    }

    public String getProcessor() {
        return processor;
    }

    public double getDisplaySizeBaseInches() {
        return displaySizeBaseInches;
    }

    public String getRam() {
        return ram;
    }

    public String getRamType() {
        return ramType;
    }

    public String getPrintResoulation() {
        return printResoulation;
    }

    public String getLens() {
        return lens;
    }
    
    
}
