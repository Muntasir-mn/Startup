/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package redox;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;


/**
 *
 * @author acer
 */
public class CatalogController implements Initializable {

    @FXML
    private ListView<String> listView;
    @FXML
    private TableView<Product> tableView;
    
    ObservableList<String> categoryList;
    ObservableList<Product> productList;
    ObservableList<Product> filteredProductList;
    @FXML
    private TableColumn<Product, Number> idColumn;
    @FXML
    private TableColumn<Product, String> nameColumn;
    @FXML
    private TableColumn<Product, Number> priceColumn;
    @FXML
    private TableColumn<Product, String> generationColumn;
    @FXML
    private TableColumn<Product, String> processorColumn;
    @FXML
    private TableColumn<Product, Number> displayColumn;
    @FXML
    private TableColumn<Product, String> ramColumn;
    @FXML
    private TableColumn<Product, String> ramTypeColumn;
    @FXML
    private TableColumn<Product, String> printResolutionColumn;
    @FXML
    private TableColumn<Product, String> lensColumn;
    @Override
    @SuppressWarnings("unchecked")
    public void initialize(URL url, ResourceBundle rb) {
       
        categoryList = FXCollections.observableArrayList();
        productList = FXCollections.observableArrayList();
        filteredProductList = FXCollections.observableArrayList();
        
        listView.setItems(categoryList);
        tableView.setItems(filteredProductList);
    
        idColumn.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getProductId()));
        nameColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getProductName()));
        priceColumn.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getPrice()));
        generationColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getGeneration()));
        displayColumn.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getDisplaySizeBaseInches()));    
        ramColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getRam()));
        ramTypeColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getRamType()));
        printResolutionColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getPrintResoulation())); 
        lensColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getLens()));
        
          try {
            Connection connection = (Connection) DriverManager.getConnection(
                    "jdbc:mysql://localhost/hardwares",
                    "root",
                    "java");
            Statement statement = (Statement) connection.createStatement();
            String query;
            
            query = "select * from ProductCategory;";
            ResultSet resultSet = statement.executeQuery(query);
            
            while (resultSet.next()) {
                String category = resultSet.getString("category");
                categoryList.add(category);
            }
            
            query = "select * from Product;";
             resultSet = statement.executeQuery(query);
            
            while (resultSet.next()) {
                int productId = resultSet.getInt("productId");
                String productName = resultSet.getString("productName");
                String productCategory = resultSet.getString("productCategory");
                int price = resultSet.getInt("price");
                String generation = resultSet.getString("generation");
                String processor = resultSet.getString("processor");
                double displaySizeBaseInches = resultSet.getDouble("displaySizeBaseInches");
                String ram = resultSet.getString("ram");
                String ramType = resultSet.getString("ramType");
                String printResolution = resultSet.getString("printResolution");
                String lens = resultSet.getString("lens");
                
                Product product = new Product(productId, productName, productCategory, price, generation,
                processor,displaySizeBaseInches, ram, ramType, printResolution, lens );
                productList.add(product);
            }
           
            filteredProductList.addAll(productList);
            
        } catch (SQLException ex) {
            Logger.getLogger(CatalogController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void handleCategorySelectAction(MouseEvent event) {
        ObservableList<String> category = listView.getSelectionModel().getSelectedItems();
          filteredProductList.clear();
          productList.stream().filter((product) -> (product.getProductCategory().equals(category))).forEachOrdered((product) -> {
              filteredProductList.add(product);
        });
        
    }

}
